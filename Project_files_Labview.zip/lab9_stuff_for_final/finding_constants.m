V = four_second_data(2:end);

Phi = [four_second_data(1:end-1),ones(1676,1)*6];

constants=Phi\V
%%

sys = tf([constants(2)],[1,-constants(1)],0.005);

figure(1)
step(sys);

figure(2)
plot(stepresponse1(:,1),four_second_data)
