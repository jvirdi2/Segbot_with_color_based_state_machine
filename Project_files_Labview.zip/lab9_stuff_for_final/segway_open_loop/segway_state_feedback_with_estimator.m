mR = .884;   %Kg  Mass of rod or body
R = 0.0508;  %m  radius of wheel
L = 0.081;  %m center of mass from wheel center
%theta is angle of rod or body
%phi is the rotation angle of the wheel/motor
iR = 0.03;  %Kg-m^2 moment of Inertia rod or body about its center of mass found in Solid Works
g = 9.804;
%Iw = Itire + Imotor shaft and rotor
m_tire = 0.045;  %Kg

I_tire = (m_tire*(2*R)^2)/8;  %Kg-m^2  tire, plastic circle, and aluminum hub
m_motorshaft = 0.0136;  %Kg This is an approximation
I_motorshaft = ((0.006^2)/8)*m_motorshaft;  %Kg-m^2  shaft diameter is 6mm
I_motorrotor = ((9.8839e-7)/2)*30^2;  %Kg-m^2  Guess here using a known motor's rotor inertia dividing by 2 and multiplying by gear ratio Squared
iW = I_tire + I_motorshaft + I_motorrotor; %Kg-m^2 Inertia of entire wheel parts
mW = m_tire + m_motorshaft;  %Kg mass wheel and all spinning parts, approx for motor rotor

iW = 2*iW;  %Kg-m^2 Two wheels in the plane
mW = 2*mW;  %m Two wheels in the plane

% mR = 815/1000;      % Mass
% L= 6.2/100;
% iR = (mR*L*L);      % Inertia
% 
% 
% % Wheel Properties 
% mW = (22.6+8.1)/1000;        % Mass
% R = (5/100);         % Radius
% iW = (mW*R*R)/2;     % Inertia
% 
% 
% % Other Properties
% g = 10;

% Linearized Model Terms
sA = iW+(mW+mR)*R^2;
sB = mR*R*L;
sC = mR*R*L;
sD = iR+mR*L^2;
sE = mR*g*L;
% Further Terms
alpha1 = (sC+sA)/(sC*sB-sA*sD);
beta1 = -sA*sE/(sC*sB-sA*sD);
alpha2 = (1-sB*alpha1)/sA;
beta2 = -sB*beta1/sA;

% State Space Matrices
A = [[0 1 0 0];
    [0 0 beta2 0];
    [0 0 0 1];
    [0 0 beta1 0]];
B = [0;alpha2;0;alpha1];
C = [[1 0 0 0];
    [0 0 0 1]];



for scale = 2
    % For state feedback law
    p = [-3 -4 -0.2 -0.3]*scale;                 %[-3 -4 -0.2 -0.3];
    K = place(A,B,p);

    desired_phi_position=10;
    for_finding_r=(inv(A-B*K))*B;
    r=(-1)*desired_phi_position/for_finding_r(1);

    % For observer stuff
    p1 = [-3 -4 -3 -4];
    L = place(A',C',p1)';

    % Initial condition
    X_initial = [0;0;0.2;0];
    Xhat_initial=[0;0;0.22;0];

    tf = 30;
    dt = 0.001;
    X =  zeros(4,tf/dt+1);
    Xhat=zeros(4,tf/dt+1);

    X(:,1) = X_initial;
    Xhat(:,1)=Xhat_initial;

    tao = zeros(1,tf/dt+1);


    tao(:,1)=-K*Xhat(:,1)+r;

    % Linearized Control of Segway
    % for time=dt:dt:tf
    %     col = round(time/dt+1);
    %     X(:,col) = X(:,col-1)+dt*(A*X(:,col-1)+B*tao(1,col-1));
    %     
    %     y_system = C*X(:,col-1);
    %     yhat = C*Xhat(:,col-1);
    %     
    %     Xhat(:,col) = Xhat(:,col-1)+dt*(A*Xhat(:,col-1)+B*tao(1,col-1)+L*(y_system-yhat));
    %     error(:,col) = Xhat(:,col)-Xref;
    %     tao(1,col) = -K*error(:,col)+alpha3;  
    % end

    % % Non Linear implementation of linear based controller
    for time=dt:dt:tf
        col = round(time/dt+1);  

        % Non Linear State Solutions
        A_NL=[[sA sB*cos(X(3,col-1))];[sC*cos(X(3,col-1)) sD]];
        B_NL=[-sC*(X(4,col-1)^2)*sin(X(3,col-1));-sE*sin(X(3,col-1))];
        C_NL=[1;-1];

        double_deriv= inv(A_NL)*((-1)*B_NL+C_NL*tao(1,col-1));

        X(2,col)= (double_deriv(1)*dt+X(2,col-1));
        X(1,col)=X(1,col-1)+dt*X(2,col);

        X(4,col)= (double_deriv(2)*dt+X(4,col-1));
        X(3,col)=X(3,col-1)+dt*X(4,col);

        y_system = C*X(:,col-1);
        yhat = C*Xhat(:,col-1);

        Xhat(:,col) = Xhat(:,col-1)+dt*(A*Xhat(:,col-1)+B*tao(1,col-1)+L*(y_system-yhat));
        tao(1,col) = -K*Xhat(:,col)+r;  


    end
    display(scale)
    max1 = max(abs(Xhat(1,:)));
    max2 = max(abs(Xhat(2,:)));
    max3 = max(abs(Xhat(3,:)));
    max4 = max(abs(Xhat(4,:)));
    [max1,max2,max3,max4]
end

